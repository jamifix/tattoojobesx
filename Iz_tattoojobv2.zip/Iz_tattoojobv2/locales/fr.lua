Locales['fr'] = {
  ['tattoo_shop_prompt'] = 'Appuyez sur  ~INPUT_PICKUP~ accéder au ~y~catalogue des tatouages~s~',
  ['money_amount'] = '<span style="color:green;">$%s</span>',
  ['part'] = 'partie %s',
  ['go_back_to_menu'] = '< Retour',
  ['tattoo_item'] = 'Tatouage %s - %s',
  ['tattoos'] = 'Tatouages',
  ['tattoo_shop'] = 'Salon de tatouage',
  ['bought_tattoo'] = 'Vous avez acheté un ~y~tatouage~s~ pour ~r~$%s~s~',
  ['not_enough_money'] = 'Vous n\'avez pas ~r~assez d\'argent~s~ pour ce tatouage ! Il manque ~r~$%s~s~'
}