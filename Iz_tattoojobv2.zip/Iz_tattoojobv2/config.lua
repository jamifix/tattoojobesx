Config = {}
Config.DrawDistance = 15.0
Config.Size = {x = 1.2, y = 1.2, z = 1.5}
Config.Color = {r = 0, g = 128, b = 255}
Config.Type = 27
Config.Locale = 'fr'

